const timeelement = document.getElementById('timer')
const start = document.getElementById('start')
const stop = document.getElementById('stop')
const reset = document.getElementById('stop')


